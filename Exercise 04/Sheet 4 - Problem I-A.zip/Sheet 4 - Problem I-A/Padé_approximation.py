#!/usr/bin/env python
# coding: utf-8

# We compare our three Padé approximations with the true function $f(x)=e^x$.

# In[2]:


from matplotlib import pyplot as plt 
import numpy as np
import math

# P[7,0]
def p_70(x):
    return 1 + x + 1/2*x**2 + 1/6*x**3 + 1/24*x**4 + 1/120*x**5 + 1/720*x**6 + 1/5040*x**7

# P[3,4]
def p_34(x):
    return (1 + 3/7*x + 1/14*x**2 + 1/210*x**3) / (1 - 4/7*x + 1/7*x**2 - 2/105*x**3 + 1/840*x**4)

# P[2,5]
def p_25(x):
    return (1 + 2/7*x + 1/42*x**2) / (1 - 5/7*x + 5/21*x**2 - 1/21*x**3 + 1/168*x**4 - 1/2520*x**4)

test = np.array([0.5, 1, 2, 5])
v_70 = np.array([p_70(x) for x in test])
v_34 = np.array([p_34(x) for x in test])
v_25 = np.array([p_25(x) for x in test])
v_f = np.array([np.exp(x) for x in test])

diff_70 = abs(v_70-v_f)
diff_34 = abs(v_34-v_f)
diff_25 = abs(v_25-v_f)

print("True function evaluated at x=0.5, 1, 2, 5")
print("f(x)=exp(x):", v_f)
print("Approximations evaluated at x=0.5, 1, 2, 5")
print("P[7,0]: ", v_70)
print("P[3,4]: ", v_34)
print("P[2,5]: ", v_25)
print("Residuals:")
print("For P[7,0]:", diff_70)
print("For P[3,4]:", diff_34)
print("For P[2,5]:", diff_25)

# x values for the plot
x = [r for r in np.arange(-5, 5, 0.01)]

# y values obtained from the approximations
y_70 = [p_70(item) for item in x]
y_34 = [p_34(item) for item in x]
y_25 = [p_25(item) for item in x]

plt.plot(x, np.exp(x), label='exp(x)')
plt.plot(x, y_70, label='P[7,0]')
plt.plot(x, y_34, label='P[3,4]')
plt.plot(x, y_25, label='P[2,5]')
plt.xlabel("x")
plt.ylabel("y")
plt.legend()
plt.title("Comparison between the Padé approximations and the true function")


# From the residuals and the plot we see that at $x=5$ $P[7,0]$ is the most accurate, while at $x=0.5, 1, 2$ the most accurate one is $P[3,4]$.

# In[ ]:




